package com.zyx.client;

public interface iFileInterface {
    /**
     *
     * @param sourceFile 待上传的文件路径
     * @param url 服务端接口地址
     * @return 文件路径UUID
     */
    public String upload(String sourceFile,String url);

    /**
     *
     * @param uuid 文件的uuid
     * @param url json接口路径
     * @return json格式的文件
     */
    public String getJson(String uuid,String url);


    /**
     *
     * @param dir 本地文件路径
     * @param fileName 本地文件名
     * @param url 获取文件的url
     * @return 文件获取状态
     */
    public String getFile(String url,String dir,String fileName);
}
