package com.zyx;
import com.zyx.dao.FileDao;
import com.zyx.entity.FileEntity;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLEncoder;

import static com.alibaba.druid.sql.parser.Token.BY;

public class DownLoadServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse resp) throws ServletException, IOException {
        //获取请求传递文件名(需要下载的文件)
        String fileId = request.getParameter("id");
        FileEntity fe = FileDao.loadFile(fileId);
        if(null != fe){
            String fileName = fe.getFileName();
            resp.reset();
            resp.setContentType("application/octet-stream;charset=UTF-8");
            resp.setHeader("Content-Disposition","attachment; filename="+fe.getFileName());
            FileInputStream fis=new FileInputStream(fe.getPath());
            ByteArrayOutputStream baos=new ByteArrayOutputStream();
            byte[] buffer=new byte[1024];
            int count=0;
            while((count=fis.read(buffer,0,1024))>=0){
                baos.write(buffer,0,count);
            }
            fis.close();

            ServletOutputStream out=resp.getOutputStream();
            out.write(baos.toByteArray());
            out.flush();
            out.close();

        }

    }
}
