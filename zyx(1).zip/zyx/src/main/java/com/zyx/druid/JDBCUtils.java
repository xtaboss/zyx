package com.zyx.druid;

import com.alibaba.druid.pool.DruidDataSourceFactory;

import javax.sql.DataSource;
import java.io.InputStream;
import java.sql.*;
import java.util.Properties;

public class JDBCUtils {
   private String JDBC_Driver ="com.mysql.jdbc.Driver";
   private String URL ="jdbc:mysql://localhost:3306/zyx";
   private String user ="zyx";
   private String password ="zyx123456";

   Connection con;
   Statement st;

   public JDBCUtils(){
       try{
           Class.forName(JDBC_Driver);
           con = DriverManager.getConnection(URL,user,password);
           st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
       }catch (Exception e){
           e.printStackTrace();
       }
   }
   public  Connection getCon(){
       return con;
   }
}
