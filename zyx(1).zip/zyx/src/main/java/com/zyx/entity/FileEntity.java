package com.zyx.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

public class FileEntity implements Serializable {

    private String id;//id
    private long size;//文件大小
    private String type;//文件类型，即后缀名
    private String fileName;//原文件名
    private Date date;//创建时间
    private String path;//文件路径

    public FileEntity() {
    }

    public FileEntity(String id, long size, String type, String fileName, Timestamp date, String path) {
        this.id = id;
        this.size = size;
        this.type = type;
        this.fileName = fileName;
        this.date = date;
        this.path = path;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public long getSize() {
        return size;
    }

    public void setSize(long size) {
        this.size = size;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
}
