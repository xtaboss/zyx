package com.zyx;
import com.zyx.common.DateUtils;
import com.zyx.common.IDUtils;
import com.zyx.druid.JDBCUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.ProgressListener;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;
import java.util.List;

public class SaveFileController extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse resp) throws ServletException, IOException {
        try {
            request.setCharacterEncoding("Utf-8");
            //创建一个工厂
            DiskFileItemFactory factory = new DiskFileItemFactory();
            factory.setSizeThreshold(1024*1024*1024);//设置缓冲区
            //创建一个ServletFileUpload对象（构造方法中需要factory帮忙）
            ServletFileUpload upload = new ServletFileUpload(factory);
            upload.setSizeMax(102400000);
            upload.setProgressListener(new ProgressListener() {
                @Override
                public void update(long l, long ll, int i) {
                    //第一个参数  已经上传的字节的个数 4096个字节
                    //第二个参数  上传的总字节数
                    //第三参数    上传的第几个组件
                    System.out.println("正在传递第"+i+"个组件"+"已经上传"+(int)(double)l/(double)ll*100+"%");
                }
            });
            //通过upload解析request对象 （解析目的是因为请求携带的信息都在request对象中）
            List<FileItem> itemList = null;
            //将list中所有的item元素遍历
            itemList = upload.parseRequest(request);
            for (FileItem item :itemList){
                if (item.isFormField()) {//一个普通的组件
                    //注意不能使用request.getPacameter();来获取  request对象已经被解析了
                    String key=item.getFieldName();
                    String value=item.getString();
                    System.out.println(request.getParameter("usernamae"));
                    System.out.println(key+"--"+value);
                }else {//是一个file文件
                    String key=item.getFieldName();//获取组件名name属性
                    String id= IDUtils.getUUID();
                    String Folder = DateUtils.getYMD(new Date());

                    String realFileName=item.getName();//获取上传文件的真实文件名
                    if(null !=realFileName &&!"".equals(realFileName)){
                        System.out.println(key+"--"+realFileName);
                        InputStream inputStream=item.getInputStream();//获取输入流
                        OutputStream outputStream=new FileOutputStream("D:/ggg/"+realFileName);
                        byte [] b=new byte[1024];
                        int length=inputStream.read(b);
                        while (length!=-1){
                            outputStream.write(b,0, b.length);
                            outputStream.flush();
                            length=inputStream.read(b);
                        }
                        inputStream.close();
                        outputStream.close();
                        try{
                            String saveFile ="insert into tb_file values (?,?)";
                            Connection con = new JDBCUtils().getCon();
                            PreparedStatement ps = con.prepareStatement(saveFile);
                            ps.setString(1,"11111");
                            ps.setString(2,"Abc");
                             ps.executeUpdate();
                        }catch(Exception e){
                            e.printStackTrace();
                        }
                    }


                }
            }
        } catch (FileUploadException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req, resp);
    }
}
