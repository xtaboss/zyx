package com.zyx.common;

/**
 * 配置常量
 */
public class Constants {
    public static final String DIR = "d:/ggg/";
}

