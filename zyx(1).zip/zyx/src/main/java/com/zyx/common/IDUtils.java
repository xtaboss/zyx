package com.zyx.common;

import java.util.UUID;

/**
 * ID生成器
 */
public class IDUtils {
    public static String getUUID(){
        String uuid = UUID.randomUUID().toString().replaceAll("-","");
        return uuid;
    }
}
