package com.zyx.common;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 日期格式化类
 */
public class DateUtils {

    public static String getYMD(Date date){
        DateFormat df =new SimpleDateFormat("yyyyMMdd");
        return df.format(date);
    }
}
