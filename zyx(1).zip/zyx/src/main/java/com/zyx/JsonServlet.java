package com.zyx;

import com.alibaba.fastjson.JSONObject;
import com.zyx.dao.FileDao;
import com.zyx.entity.FileEntity;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;

public class JsonServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse resp) throws ServletException, IOException {
        //获取请求传递文件名(需要下载的文件)
        String fileId = request.getParameter("id");
        FileEntity fe = FileDao.loadFile(fileId);

        if(null != fe){
            String jsonString = JSONObject.toJSONString(fe);
            resp.getWriter().write(jsonString);

        }

    }
}
