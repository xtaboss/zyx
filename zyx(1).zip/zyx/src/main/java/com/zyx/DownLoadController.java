package com.zyx;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;

public class DownLoadController extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse resp) throws ServletException, IOException {
        //获取请求传递文件名(需要下载的文件)
        String fileName = request.getParameter("fileName");
        //通过fileName找到一个服务器中的真实文件的内容
        InputStream inputStream= new FileInputStream("D://ggg/"+fileName);
        //如果有中文
        URLEncoder.encode(fileName,"UTF-8");
        //将内容响应回浏览器
        OutputStream outputStream= resp.getOutputStream();
        byte[] b = new byte[1024];
        int length= inputStream.read(b);
        while (length!=-1){
            outputStream.write(b,0,length);
            outputStream.flush();
            length=inputStream.read(b);
        }
    }
}
