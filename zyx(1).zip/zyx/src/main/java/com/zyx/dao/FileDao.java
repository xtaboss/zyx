package com.zyx.dao;

import com.zyx.common.IDUtils;
import com.zyx.druid.JDBCUtils;
import com.zyx.entity.FileEntity;

import java.sql.*;

public class FileDao {

    public static  String saveFile(FileEntity fe){
        try{
            Connection con = new JDBCUtils().getCon();

            String savesql ="insert into tb_file values (?,?,?,?,?,?)";

            PreparedStatement ps = con.prepareStatement(savesql);
            ps.setString(1,fe.getId());
            ps.setLong(2,fe.getSize());
            ps.setString(3,fe.getType());
            ps.setString(4,fe.getFileName());
            Timestamp sqlDate = new Timestamp(fe.getDate().getTime());
           // java.sql.Date date = new Date(new java.util.Date().getSeconds());
            ps.setTimestamp(5,sqlDate);
            ps.setString(6,fe.getPath());
            ps.executeUpdate();
            return fe.getId();
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;

    }

    public static  FileEntity loadFile(String id){
        FileEntity fe = null;
        try{
            Connection con = new JDBCUtils().getCon();

            String selectSql ="select * from  tb_file where id=?";

            PreparedStatement ps = con.prepareStatement(selectSql);
            ps.setString(1,id);

            ResultSet rs = ps.executeQuery();
            DatabaseMetaData metaData = con.getMetaData();
            ResultSetMetaData rsm = ps.getMetaData();
            for(int i=1;i<rsm.getColumnCount();i++){
                System.out.println("列名："+rsm.getColumnLabel(i)+"\t类型："+rsm.getColumnTypeName(i)+"\t是否为空："+rsm.isNullable(i));
            }
            while (rs.next()){
                for(int i=1;i<rsm.getColumnCount();i++){
                    System.out.println("列名："+rsm.getColumnLabel(i)+"\t值："+rs.getObject(i));
                }
                fe = new FileEntity();
                fe.setId(rs.getString("id"));
                fe.setSize(rs.getLong("size"));
                fe.setType(rs.getString("type"));
                fe.setFileName(rs.getString("fileName"));
                fe.setDate(rs.getTimestamp("date"));
                fe.setPath(rs.getString("path"));
            }
            return fe;
        }catch (Exception e){
            e.printStackTrace();
        }
        return fe;

    }

}
