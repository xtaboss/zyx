CREATE TABLE `tb_file` (
  `id` varchar(32) NOT NULL COMMENT 'id',
  `size` bigint(20) DEFAULT NULL COMMENT '文件大小',
  `type` varchar(5) DEFAULT NULL COMMENT '文件类型，后缀名',
  `fileName` varchar(32) DEFAULT NULL COMMENT '原文件名',
  `date` datetime DEFAULT NULL COMMENT '创建日期',
  `path` varchar(256) DEFAULT NULL COMMENT '本地存储路径',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8